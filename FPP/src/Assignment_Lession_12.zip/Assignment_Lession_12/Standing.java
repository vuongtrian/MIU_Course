package Assignment_Lession_12;

public enum Standing {
    FRESHMAN, SOPHOMORE, JUNIOR, SENIOR;
}
