package miu.edu.WebShop.Domain;

public interface IPaymentType {
}
