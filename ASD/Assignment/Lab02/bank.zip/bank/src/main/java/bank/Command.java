package bank;

public interface Command {
    void execute();
    void unExecute();
}
