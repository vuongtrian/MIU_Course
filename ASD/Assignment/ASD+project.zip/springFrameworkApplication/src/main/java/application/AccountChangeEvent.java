package application;

public class AccountChangeEvent {

    @Override
    public String toString() {
        return "AccountChangeEvent: account has been changed";
    }
}
