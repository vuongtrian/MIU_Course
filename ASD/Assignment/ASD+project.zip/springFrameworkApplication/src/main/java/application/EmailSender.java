package application;

public interface EmailSender {
	void sendEmail(String content);
}
