package application;

public interface ISmsSender {
    public void sendSMS(String content);
}
