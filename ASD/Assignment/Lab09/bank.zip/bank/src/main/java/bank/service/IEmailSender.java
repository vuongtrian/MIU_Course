package bank.service;

public interface IEmailSender {
    public void send();
}
