package miu.edu;

public abstract class PaymentStrategy {
    public abstract void pay();
}
