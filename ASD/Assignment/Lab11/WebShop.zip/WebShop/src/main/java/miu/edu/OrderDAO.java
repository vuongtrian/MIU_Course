package miu.edu;

public class OrderDAO {
    public void save() {
    }
}
