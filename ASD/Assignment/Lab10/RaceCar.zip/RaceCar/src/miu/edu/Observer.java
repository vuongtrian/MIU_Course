package miu.edu;

public abstract class Observer {


    public abstract void update(int speed);
}
