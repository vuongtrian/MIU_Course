package application;

import com.FinalProject.Transaction;

public interface IMyTransactionDAO {
    public void save(Transaction transaction);
}
