package application;

import com.FinalProject.Category;
import com.FinalProject.ITransactionDAO;
import com.FinalProject.Transaction;

public interface IMyTransactionService {
    public void addTransaction();

}
