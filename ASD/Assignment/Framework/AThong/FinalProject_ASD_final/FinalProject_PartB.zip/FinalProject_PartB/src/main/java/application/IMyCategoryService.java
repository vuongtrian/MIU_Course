package application;

import com.FinalProject.Category;

public interface IMyCategoryService {
    public void addCategory();
//    public void save(Category category);
}
