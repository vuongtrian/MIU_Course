package application;

public interface IAOPService {
	public void sendMessage();
}
