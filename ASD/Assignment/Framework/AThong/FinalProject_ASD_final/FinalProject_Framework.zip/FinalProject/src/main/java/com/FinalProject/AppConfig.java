package com.FinalProject;

public class AppConfig {

}
