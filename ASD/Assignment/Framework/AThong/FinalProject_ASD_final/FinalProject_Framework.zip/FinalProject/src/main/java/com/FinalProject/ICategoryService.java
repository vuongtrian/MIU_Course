package com.FinalProject;

public interface ICategoryService {
    public void addCategory(int id, String name);
    public Category getCategory(int id);
}
