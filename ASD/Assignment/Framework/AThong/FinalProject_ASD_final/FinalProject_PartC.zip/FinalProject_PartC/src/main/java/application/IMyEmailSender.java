package application;

import com.FinalProject.NewTransactionEvent;

public interface IMyEmailSender {

    void sendEmail();
}
