package application;

public interface IMyTransactionService {
    public void welcome();
}
