package application;

public interface ICalculator {
    void method1 ();
    void method2 ();
    void showValue();
}
