package webshop.shopping;

import framework.Profile;

@Profile("")
public interface IShoppingDAO {

	void save(ShoppingCart shoppingCart);
	ShoppingCart find(int cartId);
	void print();

}
