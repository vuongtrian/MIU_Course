package framework;

import java.io.FileInputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.reflections.Reflections;

public class FWContext {

	private Map<String, Object> serviceObjectMap = new HashMap<>();
	private final String activeProfile = "spring.profiles.active";
	private ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();

	public FWContext(Runnable app) {
		try {
			
			Properties properties = new Properties();
			properties.load(new FileInputStream("src/main/resources/application.properties"));

			Reflections reflections = new Reflections("");
			Set<Class<?>> serviceTypes = reflections.getTypesAnnotatedWith(Service.class);
			for (Class<?> serviceClass: serviceTypes) {
				serviceObjectMap.put(getBeanName(serviceClass), serviceClass.getDeclaredConstructor().newInstance());
			}

			performDI(app, properties);

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	private void performDI(Runnable appClass, Properties properties) {
		try {

			for (Object bean : serviceObjectMap.values()) {
				Class<?> beanClass = bean.getClass();

				//@Autowired, @Inject for fields
				for (Field field: beanClass.getDeclaredFields()) {
					if (field.isAnnotationPresent(Autowired.class) || field.isAnnotationPresent(Inject.class)) {
						field.setAccessible(true);
						Object objectDI = findDIWithField(field, properties);
						field.set(bean, objectDI);
					} else if (field.isAnnotationPresent(Value.class)) {
						field.setAccessible(true);
						String value = valueFromProperties(properties, field);
						Object convertedValue = convertValue(value, field.getType());
						field.set(bean, convertedValue);
					}
				}

				//@Autowired for methods, @scheduled
				for (Method method: beanClass.getDeclaredMethods()) {
					if (method.isAnnotationPresent(Autowired.class)) {
						Class<?>[] parameterTypes = method.getParameterTypes();
						if (parameterTypes.length > 0) {
							method.invoke(bean, findDIWithClass(parameterTypes[0]));
						}
					} else if (method.isAnnotationPresent(Scheduled.class)) {
						Scheduled scheduledAnnotation = method.getAnnotation(Scheduled.class);
						long fixedRate = scheduledAnnotation.fixedRate();
						scheduler.scheduleAtFixedRate(() -> {
	                        try {
	                            method.invoke(bean);
	                        } catch (Exception e) {
	                            e.printStackTrace();
	                        }
						}, 0, fixedRate, TimeUnit.MILLISECONDS);
					}
				}

				//@Autowired for constructors
				for (Constructor<?> constructor: beanClass.getDeclaredConstructors()) {
					if (constructor.isAnnotationPresent(Autowired.class)) {
						Class<?>[] parameterTypes = constructor.getParameterTypes();
						int length = parameterTypes.length;
						Object[] arguments = new Object[length];
						for (int i = 0; i < length; i++) {
							arguments[i] = findDIWithClass(parameterTypes[i]);
						}
						constructor.setAccessible(true);
						serviceObjectMap.put(getBeanName(beanClass), constructor.newInstance(arguments));
					}
				}
			}
			
			//scan for appClass
			for (Field field: appClass.getClass().getDeclaredFields()) {
				if (field.isAnnotationPresent(Autowired.class) || field.isAnnotationPresent(Inject.class)) {
					field.setAccessible(true);
					Object findDIObject = findDIWithField(field, properties);
					field.set(appClass, findDIObject);
				} else if (field.isAnnotationPresent(Value.class)) {
					field.setAccessible(true);
					String value = valueFromProperties(properties, field);
					Object convertedValue = convertValue(value, field.getType());
					field.set(appClass, convertedValue);
				}
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	private Object findDIWithField(Field field, Properties properties) {
		Qualifier qualifier = field.getAnnotation(Qualifier.class);
		if (qualifier != null) {
			String qualifierValue = qualifier.value();
			return serviceObjectMap.get(qualifierValue);
		}

		return findMatchedDIClass(field.getType(), properties);
	}

	private Object findDIWithClass(Class<?> type) {
		return serviceObjectMap.get(getBeanName(type));
	}
	
	private Object findMatchedDIClass(Class<?> type, Properties properties) {
		Profile profile = type.getAnnotation(Profile.class);
		if (profile == null) {
			return findDIWithClass(type);
		}
		for (Map.Entry<String, Object> entry : serviceObjectMap.entrySet()) {
            Object bean = entry.getValue();
            Class<?> beanClass = bean.getClass();
            if (type.isAssignableFrom(beanClass)) {
            	Profile beanProfile = beanClass.getAnnotation(Profile.class);
            	if (isActiveProfile(beanProfile, properties)) {
            		return findDIWithClass(beanClass);
            	}
            }
		}
		return null;
	}

	public Object getBean(Class<?> myClass) {
		return getBeanByName(getBeanName(myClass));
	}

	public Object getBeanByName(String name) {
		return serviceObjectMap.get(name);
	}

	private String getBeanName(Class<?> myClass) {
		String className = myClass.getSimpleName();
		return Character.toLowerCase(className.charAt(0)) + className.substring(1);
	}

	private String valueFromProperties(Properties properties, Field field) {
		Value valAnnotation = field.getAnnotation(Value.class);
		String valKey = valAnnotation.value().trim();
		return properties.getProperty(valKey);
	}

	private Object convertValue(String value, Class<?> targetType) {
		if (targetType == int.class || targetType == Integer.class) {
			return Integer.parseInt(value);
		}
		if (targetType == long.class || targetType == Long.class) {
			return Long.parseLong(value);
		}
		if (targetType == float.class || targetType == Float.class) {
			return Float.parseFloat(value);
		}
		if (targetType == double.class || targetType == Double.class) {
			return Double.parseDouble(value);
		}
		if (targetType == boolean.class || targetType == Boolean.class) {
			return Boolean.parseBoolean(value);
		}
		return value;
	}
	
	private boolean isActiveProfile(Profile profile, Properties properties) {
		if (profile == null || profile.value().isEmpty()) {
			return true;
		}
		String profileValue = (String) properties.get(activeProfile);
		String profileConfig = profile.value();
		if (profileValue.equals(profileConfig)) {
			return true;
		}
		return false;
	}

}
