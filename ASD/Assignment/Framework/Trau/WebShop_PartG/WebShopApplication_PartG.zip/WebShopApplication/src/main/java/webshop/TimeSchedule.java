package webshop;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

import framework.Scheduled;
import framework.Service;

@Service
public class TimeSchedule {
	
//	@Scheduled(fixedRate = 5000)
	@Scheduled(cron = "5 0")
	public void welcome() {
		Date date = Calendar.getInstance().getTime();
        DateFormat timeFormatter = DateFormat.getTimeInstance(DateFormat.DEFAULT);
        String currenttime = timeFormatter.format(date);
        System.out.println("This task runs at " + currenttime);
	}

}
