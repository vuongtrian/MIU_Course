package webshop.shopping;

import java.util.HashMap;
import java.util.Map;

import framework.Profile;
import framework.Service;

@Service
//@Qualifier("shoppingDAO")
@Profile("Production")
public class ShoppingDAO implements IShoppingDAO {
    private Map<Integer, ShoppingCart> shoppingCarts = new HashMap<Integer, ShoppingCart>();

    @Override
    public void save(ShoppingCart shoppingCart){
        shoppingCarts.put(shoppingCart.getCartId(), shoppingCart);
    }

    @Override
    public ShoppingCart find(int cartId){
        return shoppingCarts.get(cartId);
    }
    
    @Override
    public void print() {
    	System.out.println("@Service(name = ShoppingDAO)");
    }
}
