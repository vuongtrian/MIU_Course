package webshop;

import framework.Async;
import framework.EventListener;
import framework.Service;
import webshop.events.FWEvent;

@Service
public class OrderListener {

	@Async
	@EventListener
	public void receiveOrder(FWEvent event) {
		System.out.println("OrderListener receives: " + event.getMessage());
		
//		try {
//			Thread.sleep(5000);
//			
//			int sum = 0;
//			for (int i = 0; i < 1000; i++) {
//				sum += i;
//			}
//			
//			System.out.println("Completed = " + sum);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} // Delay between invocations
		
	}
	
}
