package webshop.order;

//import framework.Service;


//@Service
public interface ISender {
	
	void sendEmail(String emailAddress, String message);
	void print();

}
