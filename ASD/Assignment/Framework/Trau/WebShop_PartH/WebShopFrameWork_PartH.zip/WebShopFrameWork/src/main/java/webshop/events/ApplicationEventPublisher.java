package webshop.events;

import framework.Service;
import webshop.FWApplication;


@Service
public class ApplicationEventPublisher {
	
	public void publishEvent(FWEvent event) {
		FWApplication.getFWContext().publishEvent(event);
	}

}
