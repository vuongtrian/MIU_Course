package webshop.events;

public class FWEvent {
	
	private String message;

    public FWEvent(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
