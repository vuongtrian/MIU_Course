package webshop.order;

public interface IPaymentType {
	
}
