package webshop;

import framework.EventListener;
import framework.Service;
import webshop.events.FWEvent;

@Service
public class OrderListener {

	@EventListener
	public void receiveOrder(FWEvent event) {
		System.out.println("OrderListener receives: " + event.getMessage());
	}
	
}
