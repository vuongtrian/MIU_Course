package application;

import framework.Profile;

@Profile("")
public interface ICalculatorDAO {
	
	void save();

}
