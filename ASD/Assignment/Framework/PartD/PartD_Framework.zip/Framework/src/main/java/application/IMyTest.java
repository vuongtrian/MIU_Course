package application;

public interface IMyTest {
    public void testMethod ();
}
